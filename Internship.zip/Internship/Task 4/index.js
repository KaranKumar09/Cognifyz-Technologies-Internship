
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, './')));

let tempStorage = {};

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));  // Set the views directory

app.post('/sign-up', (req, res) => {
    const { email, password } = req.body;
    if (!email || !password) {
        return res.status(400).send('Invalid data provided.');
    }

    tempStorage = { ...req.body };
    console.log('Stored data:', tempStorage);

    res.redirect('/signup');
});

app.get('/signup', (req, res) => {
    res.render('signup');
});

app.use((req, res) => {
    res.status(404).send('Page not found');
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server running on port http://localhost:${PORT}`));
