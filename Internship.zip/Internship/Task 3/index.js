
document.getElementById('sendBtn').addEventListener('click', function() {
    const chatInput = document.getElementById('chat-input');
    const chatBody = document.getElementById('chatBody');

    if (chatInput.value.trim() !== '') {
        const userMessage = document.createElement('div');
        userMessage.classList.add('message', 'user-message');
        userMessage.innerHTML = `<p>${chatInput.value}</p>`;
        chatBody.appendChild(userMessage);

        chatInput.value = '';
        chatBody.scrollTop = chatBody.scrollHeight;
    }
});

document.getElementById('chat-btn').addEventListener('click', function() {
    location.reload(); // Refresh the page when the New Chat button is clicked
});

document.getElementById('chat-input').addEventListener('keypress', function(event) {
    if (event.key === 'Enter') {
        document.getElementById('sendBtn').click();
        event.preventDefault(); // Prevent the default form submission behavior
    }
});
