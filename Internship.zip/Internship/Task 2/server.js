
const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const port = 3000;

// Set view engine to EJS
app.set('view engine', 'ejs');
// Set the views directory
app.set('views', path.join(__dirname, 'views'));

app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.render('index', { errors: {}, message: '' });
});

app.post('/submit', (req, res) => {
    const { username, email, password } = req.body;
    let errors = {};

    if (username.length < 5) {
        errors.username = 'Username must be at least 5 characters long.';
    }
    if (!email.includes('@')) {
        errors.email = 'Invalid email format.';
    }
    if (password.length < 6) {
        errors.password = 'Password must be at least 6 characters long.';
    }

    if (Object.keys(errors).length > 0) {
        res.render('index', { errors: errors, message: '' });
    } else {
        const userData = {
            username,
            email,
            password
        };
        res.render('result', { userData: userData });
    }
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});
